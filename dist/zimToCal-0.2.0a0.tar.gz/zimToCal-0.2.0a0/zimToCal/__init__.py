from zimToCal import task_to_cal, setup_arg_parse, ConfigStruct
from zimToStdout import task_to_stdout
